# ResistorCalculator
A simple resistor calculator made in html5.
